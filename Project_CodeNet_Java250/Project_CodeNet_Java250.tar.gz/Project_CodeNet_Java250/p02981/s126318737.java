import java.util.*;
public class Main {
    public static void main(String[] args){

        long NUM=1000000007;
        Scanner sc = new Scanner(System.in);
        // 整数の入力
        int N=sc.nextInt();
        int A=sc.nextInt();
        int B=sc.nextInt();
        System.out.println(Math.min(N*A,B));
        return;


    }
}
