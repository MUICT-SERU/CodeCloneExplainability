import java.text.ParseException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws ParseException {
		Scanner sc = new Scanner(System.in);
		int A=sc.nextInt()*sc.nextInt(),B=sc.nextInt();
		System.out.println(A>B?B:A);
	}
}
