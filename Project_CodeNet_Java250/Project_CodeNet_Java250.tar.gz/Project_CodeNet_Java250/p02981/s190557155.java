import java.io.BufferedReader;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.util.Arrays;

public class Main {
	public static void main(final String[] args){
    
    final Scanner sc = new Scanner(System.in);
    final int n = sc.nextInt();
    final List<Integer> list = new ArrayList<>();
    int a = sc.nextInt();
    int b = sc.nextInt();

    if(a * n >= b){
        System.out.println(b);
    }else{
        System.out.println(a * n);
    }

    

    



    
  

    


    


    

    
    
    



    





}
}